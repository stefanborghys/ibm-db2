#!/bin/ksh
#
# A place holder for a missing program/file
#
echo " "
echo "Program/File lib32/gskit_db2/C/icc/ReadMe.txt is not ready yet. This file is"
echo "used as a place holder for a missing file."
exit 1
